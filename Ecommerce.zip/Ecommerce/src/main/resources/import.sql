INSERT INTO products (name,brand,category,price,description,image_file_name,created_at) VALUES('giacca', 'armani', 'abbigliamento',80,'giacca','fotoGiacca.jpeg',CURRENT_TIMESTAMP);
INSERT INTO products (name,brand,category,price,description,image_file_name,created_at) VALUES('giacca uomo', 'armani', 'abbigliamento',80,'descrizione','fotoGiaccaUomo.jpeg',CURRENT_TIMESTAMP);
INSERT INTO products(name,brand,category,price,description,image_file_name,created_at) VALUES('giacca di pelle', 'armani', 'Elettronica',80,'descrizione','fotoGiaccaPelle.jpeg',CURRENT_TIMESTAMP);
