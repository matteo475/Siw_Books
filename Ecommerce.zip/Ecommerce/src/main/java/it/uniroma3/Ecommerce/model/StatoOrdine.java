package it.uniroma3.Ecommerce.model;

public enum StatoOrdine {
	 CONFERMATO,
	 SPEDITO,
	 PAGATO,
	 ANNULLATO
}
