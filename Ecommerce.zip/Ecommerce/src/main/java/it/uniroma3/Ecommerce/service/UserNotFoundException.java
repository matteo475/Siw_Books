package it.uniroma3.Ecommerce.service;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String message) {
		super(message);
	}

	
}
