package it.uniroma3.Ecommerce.model;

public enum AuthenticationProvider {
	LOCAL,GOOGLE	
}
