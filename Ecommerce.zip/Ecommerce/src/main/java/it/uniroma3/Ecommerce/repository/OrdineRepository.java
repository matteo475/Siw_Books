package it.uniroma3.Ecommerce.repository;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.Ecommerce.model.Ordine;

public interface OrdineRepository extends CrudRepository<Ordine, Long> {

}
